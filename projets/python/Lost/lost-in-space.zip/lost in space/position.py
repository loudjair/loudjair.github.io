#coding:utf-8

class Position:
	"""docstring for Position"""
	def __init__(self,abscisse,ordonnee):
		self.abs = abscisse
		self.ord = ordonnee