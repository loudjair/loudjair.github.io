from position import *
from iutk import *

class Attaque(Position):
	def __init__(self,abscisse,ordonnee,taille,couleur,x=None,y=None):
		Position.__init__(self,abscisse,ordonnee)
		self.taille = taille
		self.couleur = couleur
		self.TIR = None
		"""
			Cette condition est pour le mode "précision" afin de mieux viser
			l'adversaire , ce mode est réservé pour le boss 
		"""
		if x != None and y != None:
			if x-self.abs != 0:
				if y-self.ord != 0:
					self.coef_dir = (y-self.ord)/(x-self.abs)
					self.origine = y - x*self.coef_dir
					self.x = x
					self.y = y
				else:
					self.coef_dir = "abscisse"
					self.x = x
			elif x-self.abs == 0 and y-self.ord == 0:
				self.coef_dir ="origine"
			else:
				self.coef_dir ="ordonnee"
				self.y = y

	def tirer(self):
		self.TIR = cerclePlein(self.abs,self.ord,self.taille,self.couleur)

	def effacer(self):
		efface(self.TIR)