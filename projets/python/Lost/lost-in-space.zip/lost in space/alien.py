#coding:utf-8
from position import *
from iutk import *
from math import *
from attaque import *

class Alien(Position):
	def __init__(self,abscisse,ordonnee,pas_x,pas_y,taille=10,couleur="green"):
		Position.__init__(self,abscisse,ordonnee)
		
		"""
			Caracteristiques physique
		"""
		self.taille = taille
		self.couleur = couleur
		self.pas_x = pas_x
		self.pas_y = pas_y

		"""
			Les dimensions de chaque membre de la tête
		"""
		self.largeur_tete = [x for x in range(self.abs-taille,self.abs+taille+1)]
		self.dim_menton = (self.abs,self.ord+taille)
		self.dim_tete = []

		self.dim_yeux = {"oeil_g":[self.abs-(taille//2),self.ord-(taille//5)],"oeil_d":[self.abs+(taille//2),self.ord-(taille//5)],"dim":(taille//5)}

		self.TETE = None
		self.OEIL_G = None
		self.OEIL_D = None


	def dessiner(self):
		# On dessine le crâne
		for x in self.largeur_tete:
			hauteur = sqrt(fabs(pow(self.taille,2)-pow(self.abs-x,2)))
			hauteur_finale = self.ord - hauteur
			self.dim_tete.append((x,hauteur_finale))

		self.dim_tete.append(self.dim_menton)
		self.TETE = polygonePlein(self.dim_tete,self.couleur,"black")

		# On dessine les yeux
		self.OEIL_G = cerclePlein(self.dim_yeux["oeil_g"][0],self.dim_yeux["oeil_g"][1],self.dim_yeux["dim"],"black")
		self.OEIL_D = cerclePlein(self.dim_yeux["oeil_d"][0],self.dim_yeux["oeil_d"][1],self.dim_yeux["dim"],"black")
		
	def attaquer(self,mode=None,x=None,y=None):
		if mode == None:
			return Attaque(self.dim_menton[0],self.dim_menton[1]+10,2,self.couleur)
		elif mode =="precision":
			return Attaque(self.dim_menton[0],self.dim_menton[1]+10,2,self.couleur,x,y)
	
	def eliminer(self):
		efface(self.TETE)
		efface(self.OEIL_G)
		efface(self.OEIL_D)

	def mise_a_jour_position(self):
		self.largeur_tete = [x for x in range(self.abs-self.taille,self.abs+self.taille+1)]
		self.dim_menton = (self.abs,self.ord+self.taille)
		self.dim_tete = []
		self.dim_yeux = {"oeil_g":[self.abs-(self.taille//2),self.ord-(self.taille//5)],"oeil_d":[self.abs+(self.taille//2),self.ord-(self.taille//5)],"dim":(self.taille//5)}