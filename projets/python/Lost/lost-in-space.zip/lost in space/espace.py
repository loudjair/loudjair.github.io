#coding:utf-8
from iutk import *
from position import *
from random import randint

class Etoile(Position):
	def __init__(self,abscisse,ordonnee,taille):
		Position.__init__(self,abscisse,ordonnee)
		self.taille = taille
		self.ETOILE = None

	def dessiner(self):
		self.ETOILE = cerclePlein(self.abs,self.ord,self.taille,"white")
	def effacer(self):
		efface(self.ETOILE)



class Espace(Position):
	def __init__(self,abscisse,ordonnee,hauteur):
		Position.__init__(self,abscisse,ordonnee)
		self.hauteur = hauteur
		self.constellations = []

		# Limites des bordures à ne pas dépasser par les aliens et le vaisseau
		self.LIMITE_A = [self.abs+10,self.abs*3-10,self.ord+10,self.hauteur//2]
		self.LIMITE_V = [self.abs+21,self.abs*3-21,self.ord+20,self.hauteur-10]
	
	def creation(self,abscisse=825,nbr=15,genre=0):
		rectanglePlein(self.abs,self.ord,abscisse,self.hauteur,"black")
		for etoile in range(nbr):
			if genre == 0:
				pos = randint(self.abs+10,self.abs*3-10),randint(self.ord+10,self.hauteur)
			elif genre == 1:
				pos = randint(0,1100),randint(0,600)
			if etoile > 10:
				self.constellations.append(Etoile(pos[0],pos[1],2))
			else:
				self.constellations.append(Etoile(pos[0],pos[1],1))
			self.constellations[etoile].dessiner()

	def animer_etoiles(self,genre=0):
		for etoile in self.constellations:
			etoile.effacer()
			if etoile.ord < self.hauteur:
				etoile.ord += 2
			else:
				if genre == 0:
					etoile.abs = randint(self.abs+10,self.abs*3-10)
				else:
					etoile.abs = randint(10,1050)
				etoile.ord = 0
			etoile.dessiner()
			