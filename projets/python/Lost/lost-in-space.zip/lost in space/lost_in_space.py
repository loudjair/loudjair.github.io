#coding:utf-8
from iutk import *
from jeu import *
from menu import *

if __name__ == '__main__':

	space = Jeu(1100,600,"Lost in space")
	menu = Menu(1100,600)
	space.ouvrirFenetre()
	niveau = menu.affiche_menu()
	if niveau != "Quitter":
		# 3 situations possibles: 0 (Quitter) , 1(Recommencer) et 2 (Le joueur a gagné ou perdu)  
		situation = 0
		while True :
			space.demarrage(niveau)
			situation = space.partie_en_cours()
			if situation == 0:
				break
			elif situation == 1:
				space.recommencer()
			elif situation == 2:
				situation = space.fin_de_partie()
				if situation == 0:
					break
				elif situation == 1:
					space.recommencer()

	fermeFenetre()