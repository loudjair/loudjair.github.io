#coding: utf-8

from iutk import *
from vaisseau import *
from espace import *
from time import *
from random import randint
from math import *

class Menu:
	def __init__(self,largeur,hauteur):
		self.largeur = largeur
		self.hauteur = hauteur

		"""
			L'espace et le vaisseau c'est pour l'aspect décoratif

		"""
		self.ESPACE = Espace(0,0,self.hauteur)
		self.nb_etoile = 30
		self.type_d_espace = 1
		self.VAISSEAU = Vaisseau(largeur//2,400,20,[0,400,0,500])

		"""
			Les choix du menu
		"""
		self.CHOIX_JOUER = None
		self.JOUER = None
		self.CHOIX_REGLE = None
		self.REGLE = None
		self.QUITTER = None
		self.CHOIX_QUITTER = None
		self.RETOUR = None
		self.CHOIX_RETOUR = None

		"""
			Les outils de transitions
		"""
		self.coef = 0 
		self.origine = 0

		self.TOUCHES = {"Haut":None,"Gauche":None,"Bas":None,"Droite":None,"Espace":None}
		self.FLECHES = {"Haut":None,"Gauche":None,"Bas":None,"Droite":None}

		self.MENU_DIFF = None
		self.CHOIX_NIVEAU = {"Facile": None,"Moyen":None,"Difficile":None}
		self.NOM_NIVEAU = {"Facile": None,"Moyen":None,"Difficile":None}

		self.TEXTE = None

	def choix(self):
		self.CHOIX_JOUER = rectanglePlein(500,90,600,130,"#3385ff")
		self.JOUER = texteCentre(self.largeur//2,110,"Jouer","white")
		self.CHOIX_REGLE = rectanglePlein(450,150,650,190,"#3385ff")
		self.REGLE = texteCentre(self.largeur//2,170,"Règle du jeu","white")
		self.MENU_DIFF = rectanglePlein(480,200,620,240,"#3385ff")
		self.TEXTE = texteCentre(self.largeur//2,220,"Difficulté","white")
		self.CHOIX_QUITTER = rectanglePlein(490,260,610,300,"#3385ff")
		self.QUITTER = texteCentre(self.largeur//2,280,"Quitter","white")

	def effacer_choix(self):
		tab = [self.CHOIX_JOUER,self.JOUER,self.CHOIX_REGLE,self.REGLE,self.CHOIX_QUITTER,self.QUITTER,self.TEXTE,self.MENU_DIFF]
		for choix in tab:
			efface(choix)

	def effacer_regle(self):
		for touche in self.TOUCHES :
			efface(self.TOUCHES[touche])

		for touche in self.FLECHES :
			efface(self.FLECHES[touche])

		efface(self.RETOUR)
		efface(self.CHOIX_RETOUR)		
		efface(self.TEXTE)

	def effacer_difficulte(self):
		for choix in self.CHOIX_NIVEAU :
			efface(self.CHOIX_NIVEAU[choix])

		for nom in self.NOM_NIVEAU :
			efface(self.NOM_NIVEAU[nom])		

		efface(self.RETOUR)
		efface(self.CHOIX_RETOUR)		
		efface(self.TEXTE)

	def transition(self,transition):
		if transition == "regle" or transition == "difficulte":
			self.coef = ((450-self.VAISSEAU.ord)/(290-550))
			self.origine = 450 - self.coef*290
		elif transition =="menu":
			self.coef = (450-500)/(290-550)
			self.origine = 450 - self.coef*290
		self.VAISSEAU.pas["Up"] = 0
		self.VAISSEAU.pas["Down"] = 0

	def regle(self):
		self.effacer_regle()
		
		self.TOUCHES["Espace"] = rectanglePlein(350,160,530,200,"white")
		self.TOUCHES["Gauche"] = rectanglePlein(550,160,590,200,"white")
		self.FLECHES["Gauche"] = polygonePlein([(575,170),(560,180),(575,190)],"black","black")
		self.TOUCHES["Bas"] = rectanglePlein(600,160,640,200,"white")
		self.FLECHES["Bas"] = polygonePlein([(610,170),(620,190),(630,170)],"black","black")
		self.TOUCHES["Droite"] = rectanglePlein(650,160,690,200,"white")
		self.FLECHES["Droite"] = polygonePlein([(660,170),(680,180),(660,190)],"black","black")
		self.TOUCHES["Haut"] = rectanglePlein(600,110,640,150,"white")
		self.FLECHES["Haut"] = polygonePlein([(620,120),(610,140),(630,140)],"black","black")

		texte = "-Appuyer sur la barre d'espace\npour tirer.\n-Appuyer les touches directionnelles\npour diriger le vaisseau"
		self.TEXTE = texteCentre(550,290,texte,"white")
	
	def difficulte(self):
		self.effacer_difficulte()
		self.CHOIX_NIVEAU["Facile"] = rectanglePlein(500,90,600,130,"#3385ff")
		self.CHOIX_NIVEAU["Moyen"] = rectanglePlein(490,140,610,180,"#3385ff")
		self.CHOIX_NIVEAU["Difficile"] = rectanglePlein(490,190,610,230,"#3385ff")

		self.NOM_NIVEAU["Facile"] = texteCentre(self.largeur//2,110,"Facile","white")
		self.NOM_NIVEAU["Moyen"] = texteCentre(self.largeur//2,160,"Moyen","white")
		self.NOM_NIVEAU["Difficile"] = texteCentre(self.largeur//2,210,"Difficile","white")

		texte = "-Configuration du niveau."
		self.TEXTE = texteCentre(550,290,texte,"white")

	def retour(self):

		efface(self.CHOIX_RETOUR)
		efface(self.RETOUR)

		self.CHOIX_RETOUR = rectanglePlein(500,390,600,430,"#3385ff")
		self.RETOUR = texteCentre(550,410,"Retour","white")

	def affiche_menu(self):

		self.ESPACE.creation(self.largeur,self.nb_etoile,self.type_d_espace)
		self.VAISSEAU.mise_a_jour_position()
		self.VAISSEAU.lancer()

		texteCentre(self.largeur//2,30,"Lost in space","#3385ff")
		self.choix()

		choix = ""
		niveau = ["",0]
		while True:
			self.ESPACE.animer_etoiles(1)
			self.VAISSEAU.en_mouvement()

			if self.VAISSEAU.ord == self.VAISSEAU.bordure[1] and choix == "":
				self.VAISSEAU.pas["Down"] = 2
				self.VAISSEAU.pas["Up"] = 0

			elif self.VAISSEAU.ord == self.VAISSEAU.bordure[3] and choix == "":
				self.VAISSEAU.pas["Down"] = 0
				self.VAISSEAU.pas["Up"] = 2

			if self.VAISSEAU.abs != 290 and (choix == "regle" or choix == "difficulte"):
				self.VAISSEAU.abs -=10
				self.VAISSEAU.ord = self.VAISSEAU.abs*self.coef + self.origine

			if self.VAISSEAU.abs == 290 and (choix == "regle" or choix == "difficulte"):
				if choix == "regle":
					self.regle()
				elif choix == "difficulte":
					self.difficulte()
				self.retour()

			if self.VAISSEAU.abs != 550 and choix == "retour":
				self.VAISSEAU.abs +=10
				self.VAISSEAU.ord = self.VAISSEAU.abs*self.coef + self.origine

			if self.VAISSEAU.abs == 550 and choix == "retour":
				choix =""
				self.choix()

			ev = donneEvenement()
			type_ev = typeEvenement(ev)

			if type_ev =="ClicGauche" or type_ev=="ClicDroit":



				# Le joueur decide de commencer une partie
				if 500 <= clicX(ev) <= 600 and 90 <= clicY(ev) <= 130 and choix =="":
					effaceTout()
					# Le niveau par défaut est facile
					if niveau[1] == 0:
						return "facile"
					else:
						return niveau[0]

				# Le joueur consulte les règles
				elif 450 <= clicX(ev) <= 650 and 150 <= clicY(ev) <= 190 and choix =="":
					choix = "regle"
					self.transition("regle")
					self.effacer_choix()

				# Le joueur configue le niveau de difficulté
				elif 500 <= clicX(ev) <= 610 and 210 <= clicY(ev) <= 250 and choix == "":
					choix= "difficulte"
					self.transition("difficulte")
					self.effacer_choix()

				# Le joueur décide de quitter
				elif 490 <= clicX(ev) <= 610 and 260 <= clicY(ev) <= 300 and choix=="":
					return "Quitter"

				elif 500 <= clicX(ev) <= 600 and 390 <= clicY(ev) <= 430:
					# Le joueur decide de retourner au menu principal
					if choix == "regle":
						self.effacer_regle()
					elif choix == "difficulte":
						self.effacer_difficulte()
					self.transition("menu")
					choix = "retour"

					"""
						Partie de configuration du niveau jeu
					"""
				elif 500 <= clicX(ev) <= 600 and 90 <= clicY(ev) <= 130 and choix=="difficulte":
					niveau = ["facile",1]

				elif 490 <= clicX(ev) <= 610 and 140 <= clicY(ev) <= 180 and choix=="difficulte":
					niveau = ["moyen",1]
				elif 490 <= clicX(ev) <= 610 and 190 <= clicY(ev) <= 230 and choix=="difficulte":
					niveau = ["difficile",1]
				
				# Si le niveau a été configuré on retourne automatique au menu
				if niveau[1] == 1:
					self.effacer_difficulte()
					self.transition("menu")
					choix = "retour"

			miseAJour()
			sleep(0.03)