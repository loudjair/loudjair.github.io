#coding:utf-8
from iutk import *
from vaisseau import *
from armee import *
from espace import *
from time import sleep

class Jeu:
	def __init__(self,largeur,hauteur,titre):
		self.LARGEUR_F = largeur
		self.HAUTEUR_F = hauteur
		self.titre = titre

		self.VAISSEAU = None
		self.ARMEE = None
		self.ESPACE = None

		self.GAME_OVER = None
		self.MESSAGE = None
		self.transition = 30

	def ouvrirFenetre(self):
		creeFenetre(self.LARGEUR_F,self.HAUTEUR_F,self.titre)

	def demarrage(self,niveau):

		rectangle(850,480,1070,520)
		texteCentre(962,500,"Recommencer","black")
		rectangle(910,530,1020,575)
		texteCentre(962,550,"Quitter","black")

		self.ESPACE = Espace(self.LARGEUR_F//4,0,self.HAUTEUR_F)
		self.ESPACE.creation()

		if niveau == "facile":
			self.ARMEE = Armee(4,4,self.ESPACE.LIMITE_A) # 4 rangées d'aliens et 4 colonnes
		elif niveau == "moyen":
			self.ARMEE = Armee(7,7,self.ESPACE.LIMITE_A) # 4 rangées d'aliens et 4 colonnes
		elif niveau == "difficile":
			self.ARMEE = Armee(9,9,self.ESPACE.LIMITE_A) # 4 rangées d'aliens et 4 colonnes
		self.ARMEE.initialisation()

		self.VAISSEAU = Vaisseau(self.LARGEUR_F//2,(self.HAUTEUR_F//2)+250,10,self.ESPACE.LIMITE_V)
		self.VAISSEAU.mise_a_jour_position()
		self.VAISSEAU.lancer()
		points_vies = [Vaisseau(940,390,10,None),Vaisseau(1000,390,10,None),Vaisseau(1060,390,10,None)]
		self.VAISSEAU.inventaire(Vaisseau(962,230,40,None),points_vies)
		self.GAME_OVER = None

	def gestion_actions(self):
		ev = donneEvenement()
		typeEv = typeEvenement(ev)
		if typeEv == "Touche":
			if touche(ev) in self.VAISSEAU.pas.keys():
				self.VAISSEAU.accelerer(touche(ev))
			
			# Pendant l'introduction du boss final, on neutralise l'attaque du joueur
			elif touche(ev) == "space" and self.ARMEE.animation == 0:
				self.VAISSEAU.position_ennemis(self.ARMEE)
				self.VAISSEAU.attaquer()
			
		
		elif typeEv == "RAS":
			for direction in self.VAISSEAU.pas:
				if self.VAISSEAU.pas[direction] > 0:
					self.VAISSEAU.pas[direction] -=1

		elif typeEv == "ClicDroit" or typeEv=="ClicGauche":
			
			#Recommencer la partie
			if 850 <= clicX(ev) <= 1070 and 480 <= clicY(ev)<= 520:
				effaceTout()
				return 1
			#Quitter la partie
			elif 910 <= clicX(ev) <= 1020 and 530 <= clicY(ev) <= 575:
				return 0		

	def gestion_attaques(self):
		# Les attaques de l'armée
		if len(self.ARMEE.tirs) > 0:
			self.ARMEE.aliens_attaquent()

		# Les attaques du joueur
		if len(self.VAISSEAU.tirs) >0:
			if self.ARMEE.animation ==0:
				self.VAISSEAU.vaisseau_attaque()
			else:
				"""
					Pendant l'introduction du boss final,
					on éliminent les tirs du joueur
					s'ils existent
				"""
				for tir in self.VAISSEAU.tirs:
					tir.effacer()
				self.VAISSEAU.tirs.clear()

	def gestion_vies(self):
		#Le joueur perd toutes ses points de vie, c'est la fin de la partie 
		if len(self.VAISSEAU.points_vies) < 1:
			self.GAME_OVER = True
			self.transition -= int(self.transition > 0)*1
		
		#Tous les aliens ont été éliminés, le joueur va débuter l'affrontement final du Boss 
		if len(self.ARMEE.aliens) < 1 :
			if len(self.ARMEE.tirs) > 0:
				for tir in self.ARMEE.tirs:
					tir.effacer()
				self.ARMEE.tirs.clear()
			self.ARMEE.le_boss()
			self.ARMEE.aliens.append(Alien(self.LARGEUR_F//2,-100,0,0,100,"#c61aff"))
			# Regénération des points de vies avant d'affronter le boss final
			points_vies = [Vaisseau(940,390,10,None),Vaisseau(1000,390,10,None),Vaisseau(1060,390,10,None)]	
			self.VAISSEAU.regenerer(points_vies)
			
		#Le joueur a gagné la partie
		if self.ARMEE.personnage =="Boss" and self.ARMEE.points_vie <0:
			self.ARMEE.aliens[0].eliminer()
			self.GAME_OVER = False
			return 2

	def game_over(self):
		ax = bx = self.LARGEUR_F//2
		ay = by = self.HAUTEUR_F//2
		while ax >= (self.LARGEUR_F//2) -100:
			efface(self.MESSAGE)
			ax -=5
			ay -=1
			bx +=5
			by +=1
			self.MESSAGE = rectanglePlein(ax,ay,bx,by,"black","white")
			miseAJour()
			sleep(0.03)
		sleep(1)
		texteCentre(self.LARGEUR_F//2,self.HAUTEUR_F//2,"Game Over","white")
		miseAJour()
		clic = attenteClic()
		if 850 <= clic[0] <= 1070 and 480 <= clic[1] <= 520:
			effaceTout()
			return 1
		elif 910 <= clic[0] <= 1020 and 530 <= clic[1] <= 575:
			return 0	

	def partie_en_cours(self):
		while True:
			self.VAISSEAU.en_mouvement()
			self.ARMEE.position_ennemi(self.VAISSEAU)
			self.ARMEE.en_mouvement()	
			
			"""
				gestion des différentes actions que le joueur va faire:
					- Diriger le vaisseau avec les touches directionelles
					- Recommencer ou quitter la partie 

			"""
			action = self.gestion_actions()
			# 0 : Quitter la partie
			# 1 : Recommencer la partie
			if action == 0:
				return 0
			elif action == 1:
				return 1

			self.gestion_attaques()

			self.ESPACE.animer_etoiles()
			
			miseAJour()

			if self.gestion_vies() == 2 or self.transition == 0:
				return 2

			
			# Si la condition est vraie int(True): 1
			self.ARMEE.dialogue -= int(self.ARMEE.dialogue > 0)*1

			sleep(0.03)

	def fin_de_partie(self):
		if self.GAME_OVER == True:
			return self.game_over()
		elif self.GAME_OVER == False:
			ax = bx = self.LARGEUR_F//2
			ay = by = self.HAUTEUR_F//2
			while ax >= (self.LARGEUR_F//2) -100:
				efface(self.MESSAGE)
				ax -=5
				ay -=1
				bx +=5
				by +=1
				self.MESSAGE = rectanglePlein(ax,ay,bx,by,"black","white")
				miseAJour()
				sleep(0.03)
			sleep(1)
			texteCentre(self.LARGEUR_F//2,self.HAUTEUR_F//2,"Tu as gagné !","white")
			miseAJour()							
			clic = attenteClic()
			if 850 <= clic[0] <= 1070 and 480 <= clic[1] <= 520:
				effaceTout()
				return 1
			elif 910 <= clic[0] <= 1020 and 530 <= clic[1] <= 575:
				return 0

	"""
		On recommencer une nouvelle partie.
		On réinitialise toutes les données
	"""
	def recommencer(self):
		effaceTout()
		effaceTout()
		miseAJour()
		miseAJour()

		self.VAISSEAU = None
		self.ARMEE = None
		self.ESPACE = None

		self.GAME_OVER = None
		self.MESSAGE = None
		self.transition = 30
