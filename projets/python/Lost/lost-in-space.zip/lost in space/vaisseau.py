#coding:utf-8

from position import *
from iutk import *
from attaque import *
from math import *

class Composant:
	def __init__(self,couleur):		
		self.pos1 = None
		self.pos2 = None
		self.couleur = couleur
		self.dessin = None

	def modification(self,abscisse,ordonnee,taille,composant):
		if composant == "H":	
			self.pos1 = Position(abscisse-taille,ordonnee-taille)
			self.pos2 = Position(abscisse+taille,ordonnee+taille)
		elif composant == "C":
			self.pos1 = Position(abscisse-(taille//2)+2,ordonnee-(taille)*2-1)
			self.pos2 = Position(abscisse+(taille//2)-2,ordonnee-taille-1)		

	def dessiner(self):
		self.dessin = rectanglePlein(self.pos1.abs,self.pos1.ord,self.pos2.abs,self.pos2.ord,self.couleur)

class Aile:
	def __init__(self,couleur):
		self.pos1 = None
		self.pos2 = None
		self.pos3 = None
		self.couleur = couleur

		self.positions = []

		self.dessin = None

	def modification(self,abscisse,ordonnee,taille,composant):
		if composant == "G":	
			self.pos1 = Position(abscisse-taille-1,ordonnee)
			self.pos2 = Position(abscisse-(taille*2)-1,ordonnee+taille+1)
			self.pos3 = Position(abscisse-taille-1,ordonnee+taille+1)
		elif composant == "D":
			self.pos1 = Position(abscisse+taille+1,ordonnee)
			self.pos2 = Position(abscisse+(taille*2)+1,ordonnee+taille+1)			
			self.pos3 = Position(abscisse+taille+1,ordonnee+taille+1)

		self.positions = []
		for pos in [self.pos1,self.pos2,self.pos3]:
			self.positions.append((pos.abs,pos.ord))	

	def dessiner(self):
		self.dessin = polygonePlein(self.positions,self.couleur,"black")

class Vaisseau(Position):
	def __init__(self,abscisse,ordonnee,taille,bordure):
		Position.__init__(self,abscisse,ordonnee)
		
		"""
			Les caracteristiques du vaisseau
		"""
		self.taille = taille
		self.couleurs = ["red","blue","white"]
		self.bordure = bordure

		"""
			Les differents composants du vaisseau
		"""

		self.HABITACLE = Composant(self.couleurs[2])
		self.AILE_G = Aile(self.couleurs[1])
		self.AILE_D = Aile(self.couleurs[1])
		self.CANON = Composant(self.couleurs[0])

		"""
			Inventaires
		"""
		self.tirs = []
		self.points_vies = []
		self.est_blesse = 0 
		self.NOM = None
		self.OBJET = None
		self.VIES = None

		self.ennemis = None
		self.pas = {"Up":0,"Down":0,"Left":0,"Right":0}


	def inventaire(self,objet,points_vies):
		self.NOM = texteCentre(962,50,"Vaisseau","#3385ff")
		self.VIES = texteCentre(870,390,"Vies:","#3385ff")

		self.OBJET = objet
		self.OBJET.mise_a_jour_position()
		self.OBJET.lancer()

		self.points_vies = points_vies

		for point in self.points_vies:
			point.mise_a_jour_position()
			point.lancer()

	def nouvelle_position(self):
		self.ord -= self.pas["Up"]*int(self.pas["Up"] >=self.pas["Down"] and self.ord > self.bordure[2])
		self.ord += self.pas["Down"]*int(self.pas["Down"] >=self.pas["Up"]and self.ord < self.bordure[3])
		self.abs -= int(self.pas["Left"] >=self.pas["Right"] and self.abs > self.bordure[0])*self.pas["Left"]
		self.abs += int(self.pas["Right"] >=self.pas["Left"] and self.abs < self.bordure[1])*self.pas["Right"]


	def couleur_blesser(self):
		for composant in [self.HABITACLE,self.AILE_G,self.AILE_D,self.CANON]:
			if self.est_blesse%2 == 0:
				composant.couleur ="#ffb3b3"
			else:
				composant.couleur = "#ff6666"
	
	def couleur_defaut(self):
		self.HABITACLE.couleur = "white"
		self.AILE_D.couleur = self.AILE_G.couleur = "blue"
		self.CANON.couleur = "red"

	def mise_a_jour_position(self):
		self.HABITACLE.modification(self.abs,self.ord,self.taille,"H")
		self.AILE_G.modification(self.abs,self.ord,self.taille,"G")
		self.AILE_D.modification(self.abs,self.ord,self.taille,"D")
		self.CANON.modification(self.abs,self.ord,self.taille,"C")
		if self.est_blesse > 0:
			self.est_blesse -=1
			self.OBJET.est_blesse -=1


	def effacer(self):
		efface(self.HABITACLE.dessin)
		efface(self.AILE_G.dessin)
		efface(self.AILE_D.dessin)
		efface(self.CANON.dessin)

	def lancer(self):

		if self.est_blesse > 0:
			self.couleur_blesser()
		else:
			self.couleur_defaut()

		self.HABITACLE.dessiner()
		self.AILE_G.dessiner()
		self.AILE_D.dessiner()
		self.CANON.dessiner()


	def decelerer(self):

		if self.pas["Up"] > self.pas["Down"]>0:
			self.pas["Up"] =0
		if self.pas["Down"]>self.pas["Up"]>0:
			self.pas["Down"]=0
		if (self.pas["Left"]>self.pas["Right"]>0):
			self.pas["Left"] = 0
		if(self.pas["Right"]>self.pas["Left"]>0):
			self.pas["Right"] =0

	def accelerer(self,direction):
		if self.pas[direction]<20:
			self.pas[direction] += 5
			if self.pas[direction] >=5:
				self.pas[direction] +=1

	def en_mouvement(self):
		if self.OBJET != None:
			self.OBJET.effacer()
		self.effacer()
		self.decelerer()
		self.nouvelle_position()
		self.mise_a_jour_position()
		self.lancer()
		if self.OBJET != None:
			self.OBJET.lancer()

	def attaquer(self):
		self.tirs.append(Attaque(self.abs,self.CANON.pos1.ord,2,"red"))

	def position_ennemis(self,ennemis):
		self.ennemis = ennemis

	def cible_atteinte(self,tir):
		for alien in self.ennemis.aliens:
			#Si la distance des deux points est inférieure à la somme des tailles
			if sqrt(pow(alien.abs-tir.abs,2)+pow(alien.ord-tir.ord,2)) <= alien.taille+tir.taille:
					if self.ennemis.personnage == "Aliens":
						alien.eliminer()
						tir.effacer()
						self.ennemis.aliens.remove(alien)
						self.ennemis.mise_a_jour_inventaire("green")
						return True
					elif self.ennemis.personnage == "Boss":
						tir.effacer()
						self.ennemis.points_vie -= 0.5
						self.ennemis.mise_a_jour_inventaire("#c61aff")
						return True
		return False

	def deplacer_tir(self,tir):
		if tir != None:
			if self.cible_atteinte(tir) == False:	
				if tir.ord > self.bordure[2]-20:
					tir.ord -=10
					tir.effacer()
					return tir
				else:
					tir.effacer()

	def vaisseau_attaque(self):
		self.tirs = list(map(self.deplacer_tir,self.tirs))
		for tir in self.tirs:
			if tir == None:
				self.tirs.remove(tir)
			else:
				tir.tirer()


	def mise_a_jour_inventaire1(self):
		
		if len(self.points_vies) > 0:
			self.OBJET.est_blesse = 20
			self.points_vies[len(self.points_vies)-1].effacer()
			miseAJour()
			self.points_vies.pop()

	def blesser(self):
		if self.est_blesse == 0:
			self.mise_a_jour_inventaire1()
			self.est_blesse = 20

	def regenerer(self,points_vies):
		for point in self.points_vies:
			efface(point)
		self.points_vies.clear()
		self.points_vies = points_vies
		for point in self.points_vies:
			point.mise_a_jour_position()
			point.lancer()