#coding:utf-8
from tkinter import *
from tkinter import font
from tkinter import _tkinter
from time import *
import subprocess
import os
import sys

# classe qui encapsule tous les objets TKinter nÃ©cessaires Ã  la crÃ©ation d'un canevas

class CustomCanvas:
    def __init__(self,width,height,titre="tk"):
        # width and height of the canvas
        self.width=width
        self.height=height

        # root Tk object
        self.root=Tk()
        self.root.title("{}".format(titre))

        # canvas attached to the root object
        self.canvas = Canvas(self.root, width=width,
                             height = height,highlightthickness=0)

        # binding of the different event 
        self.root.protocol("WM_DELETE_WINDOW", self.eventQuit)
        self.canvas.bind("<Button-1>", self.eventHandlerButton1)
        rightButton="<Button-3>" # d'aprÃ¨s la doc le bouton droit le 3
        if sys.platform.startswith("darwin"):         # sous mac c'est le bouton 2
            rightButton="<Button-2>"
        self.canvas.bind(rightButton, self.eventHandlerButton2)
        self.canvas.bind_all("<Key>", self.eventHandlerKey)
        self.canvas.pack()
    
        # eventQueue stores the list of events received
        self.eventQueue=[]

        # font for the texte functions
        self.police=("Purisa",24)
        self.tkfont= font.Font(self.canvas, font=self.police)
        self.tkfont.height = self.tkfont.metrics("linespace")

        # marque
        self.tailleMarque=5
        self.marqueh=None
        self.marquev=None

        # update
        self.root.update()


    def update(self):
        sleep(_tkinter.getbusywaitinterval() / 1000)
        self.root.update()

    def eventHandlerKey(self,event):
        self.eventQueue.append(("Touche",event))

    def eventHandlerButton2(self,event):
        self.eventQueue.append(("ClicDroit",event))

    def eventHandlerButton1(self,event):
        self.eventQueue.append(("ClicGauche",event))

    def eventQuit(self):
        self.eventQueue.append(("Quitte",""))

    
__canevas = None


#############################################################################
# Exceptions
#############################################################################

class typeEvenementNonValide(Exception): pass
class fenetreNonCree(Exception): pass
class fenetreDejaCree(Exception): pass

#############################################################################
# Initialisation, mise Ã  jour et fermeture
#############################################################################

def creeFenetre(largeur,hauteur,titre="tk"):
    """
    CrÃ©e une fenÃªtre largeur x hauteur.
    """
    global __canevas
    if __canevas!=None:
        raise fenetreDejaCree('La fenetre a dÃ©jÃ  Ã©tÃ© crÃ©e avec la fonction "creeFenetre".')
    __canevas=CustomCanvas(largeur,hauteur,titre)


def fermeFenetre():
    """"
    DÃ©truit la fenÃªtre.
    """
    global __canevas
    if __canevas==None:
        raise fenetreNonCree("La fenetre n'a pas Ã©tÃ© crÃ©e avec la fonction \"creeFenetre\".")
    __canevas.root.destroy()
    __canevas=None


def miseAJour():
    """
    Met Ã  jour la fenÃªtre. Les dessins ne sont affichÃ©s qu'aprÃ¨s 
    l'appel Ã   cette fonction.
    """
    global __canevas
    if __canevas==None:
        raise fenetreNonCree("La fenetre n'a pas Ã©tÃ© crÃ©e avec la fonction \"creeFenetre\".")
    __canevas.update()


#############################################################################
# Fonctions de dessin
#############################################################################

####### Ligne

def ligne(ax,ay,bx,by):
    """
    Trace une ligne en noir du point (ax,ay) au point (bx,by).
    """
    global __canevas
    return __canevas.canvas.create_line(ax,ay,bx,by)

def ligneCouleur(ax,ay,bx,by,c):
    """
    Trace une ligne du point (ax,ay) au point (bx,by) de la couleur c.
    """
    global __canevas
    return __canevas.canvas.create_line(ax,ay,bx,by,fill=c)

####### Rectangle

def rectangle(ax,ay,bx,by):
    """
    Trace un rectangle en noir ayant le point (ax,ay) et le point (bx,by) 
    comme coins.
    """
    global __canevas
    return __canevas.canvas.create_rectangle(ax,ay,bx,by)

def rectangleCouleur(ax,ay,bx,by,c,taille=1):
    """
    Trace un rectangle en noir ayant le point (ax,ay) et le point (bx,by) 
    comme coins avec la couleur c.
    """
    global __canevas
    return __canevas.canvas.create_rectangle(ax,ay,bx,by,outline=c,width=taille)

def rectanglePlein(ax,ay,bx,by,c,d="black"):
    """
    Trace un rectangle plein ayant le point (ax,ay) et le point (bx,by) 
    comme coins avec la couleur c.
    """
    global __canevas
    return __canevas.canvas.create_rectangle(ax,ay,bx,by,fill=c,outline=d)

def polygonePlein(lst,c,b):
    """
    Trace un polygone qui passe par les points (lst[0],lst[1]) (lst[2],lst[3])
    etc la couleur de fond est c et celle du bord est b
    """
    global __canevas
    return __canevas.canvas.create_polygon(lst,fill=c,outline=b)
####### Cercle

def cercle(x,y,r):
    """ 
    Trace un cercle de centre (x,y) et de rayon r en noir.
    """
    global __canevas
    return __canevas.canvas.create_oval(x-r,y-r,x+r,y+r)

def cercleCouleur(x,y,r,c):
    """ 
    Trace un cercle de centre (x,y) et de rayon r de la couleur c.
    """
    global __canevas
    return __canevas.canvas.create_oval(x-r,y-r,x+r,y+r,outline=c)

def cerclePlein(x,y,r,c):
    """ 
    Trace un cercle plein de centre (x,y) et de rayon r de la couleur c.
    """
    global __canevas
    return __canevas.canvas.create_oval(x-r,y-r,x+r,y+r,fill=c,outline=c)

###### Marque

def marque(x,y,couleur="red"):
    """
    Place la marque sur la position (x,y) qui peut Ãªtre effacÃ© en appelant
    `effaceMarque()`.
    """
    global __canevas
    #effaceMarque()
    __canevas.marqueh = ligneCouleur(x-__canevas.tailleMarque,y,x+__canevas.tailleMarque,y,couleur)
    __canevas.marquev = ligneCouleur(x,y-__canevas.tailleMarque,x,y+__canevas.tailleMarque,couleur)
   
def effaceMarque():
    """ 
    Efface la marque affichÃ© par la fonction `marque`
    """
    global __canevas
    if __canevas.marqueh!=None and __canevas.marquev!=None:
        efface(__canevas.marqueh)
        efface(__canevas.marquev)
        __canevas.marqueh=None
        __canevas.marquev=None

####### Texte

def texte(x,y, texte,c):
    """
    Affiche la chaÃ®ne `texte` avec (x,y) comme coin en haut Ã  gauche dans la couleur `c`.
    """
    global __canevas
    return __canevas.canvas.create_text(x,y, text=texte, font=__canevas.police, fill=c, anchor="nw")

def texteCentre(x,y, texte, c):
    """
    Affiche la chaÃ®ne `texte` centrÃ© sur le point (x,y) dans la couleur `c`.
    """
    global __canevas
    return __canevas.canvas.create_text(x,y, text=texte, font=__canevas.police, fill=c, anchor="center")

def longueurTexte(texte):
    """
    Donne la longueur en pixel nÃ©cessaire pour afficher `texte`.
    """
    global __canevas
    return __canevas.tkfont.measure(texte)

def hauteurTexte(texte):
    """
    Donne la hauteur en pixel nÃ©cessaire pour afficher `texte`.
    """
    global __canevas
    return __canevas.tkfont.height

#############################################################################
# Efface
#############################################################################

def effaceTout():
    """
    Efface la fenÃªtre
    """
    global __canevas
    __canevas.canvas.delete("all")

def efface(objet):
    """
    Efface `objet` de la fenÃªtre
    """
    global __canevas
    __canevas.canvas.delete(objet)


#############################################################################
# Utilitaires
#############################################################################


def attenteClic():
    """
    Attend que l'utilisateur clique sur la fenÃªtre
    """
    while True:
        ev=donneEvenement()
        typeEv=typeEvenement(ev)
        if typeEv=="ClicDroit" or typeEv=="ClicGauche":
            return (clicX(ev),clicY(ev),typeEv)
        miseAJour()

def attenteTouche():
    """
    Attend que l'utilisateur clique sur la fenÃªtre
    """
    while True:
        ev=donneEvenement()
        typeEv=typeEvenement(ev)
        if typeEv=="Touche":
            return touche(ev)
        miseAJour()


def clic():
    """
    Attend que l'utilisateur clique sur la fenÃªtre
    """
    return attenteClic()

def captureEcran(file):
    """
    Fait une capture d'Ã©cran sauvegardÃ© dans `file`.png
    """
    global __canevas
    __canevas.canvas.postscript(file=file+".ps", height=__canevas.height, width=__canevas.width, colormode="color")
    subprocess.call("convert -density 150 -geometry 100% -background white -flatten "+file+".ps "+file+".png",shell=True)
    subprocess.call("rm "+file+".ps",shell=True)


#############################################################################
# Gestions des Ã©vÃ¨nements
#############################################################################

def donneEvenement():
    """ 
    Renvoie l'Ã©vÃ¨nement associe Ã  la fenÃªtre.
    """
    global __canevas
    if __canevas==None:
        raise fenetreNonCree("La fenetre n'a pas Ã©tÃ© crÃ©e avec la fonction \"creeFenetre\".")
    if len(__canevas.eventQueue)==0:
        return ("RAS","")
    else:
        return __canevas.eventQueue.pop()

def typeEvenement(evenement):
    """ 
    Renvoie une string donnant le type de evenement.
    
    Les types possibles sont:
    * 'ClicDroit'
    * 'ClicGauche'
    * 'Touche'
    * 'RAS'
    """
    nom,ev = evenement
    return nom

def clicX(evenement):
    """ 
    Renvoie la coordonnÃ©e X associÃ© Ã  evenement qui doit Ãªtre de type 'ClicDroit' ou 'ClicGauche'
    """
    nom,ev = evenement
    if not (nom=="ClicDroit" or nom=="ClicGauche"):
        raise typeEvenementNonValide('On peut pas utiliser "clicX" sur un Ã©vÃ¨nement de type ' + nom)
    return ev.x

def clicY(evenement):
    """ 
    Renvoie la coordonnÃ©e Y associÃ© Ã  evenement 
    qui doit Ãªtre de type 'ClicDroit' ou 'ClicGauche'
    """
    nom,ev = evenement
    if not (nom=="ClicDroit" or nom=="ClicGauche"):
        raise typeEvenementNonValide('On peut pas utiliser "clicY" sur un Ã©vÃ¨nement de type ' + nom)
    return ev.y

def touche(evenement):
    """ 
    Renvoie une string correspondant Ã  la touche associÃ© Ã  evenement 
    qui doit Ãªtre de type 'Touche'.
    """
    nom,ev = evenement
    if not (nom=="Touche"):
        raise typeEvenementNonValide('On peut pas utiliser "touche" sur un Ã©vÃ¨nement de type ' + nom)
    return ev.keysym

dic={}

def afficheImage(nom):
    global __canevas
    global dic
    image = PhotoImage(nom)
    dic['toto']=image
    __canevas.canvas.create_image (200,200, anchor=NW, image=image)
    __canevas.update()