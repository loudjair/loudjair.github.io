#coding:utf-8
from alien import *
from attaque import *
from random import randint
from math import *

class Armee:
	def __init__(self,ligne,colonne,bordure):
		"""
			Configuration de l'armée aliens
		"""
		self.ligne = ligne
		self.colonne = colonne
		"""
			Limite géographique + le sens du deplacement 
		"""
		self.bordure = bordure
		self.pas = [x for x in range(-5,6)]
		"""
			Les inventaires
		"""
		self.aliens = []
		self.tirs = []
		self.OBJET = None
		self.NOM = None
		self.VIE = None
		self.JAUGE = None
		self.points_vie = 250
		self.personnage = ""
		self.animation = 0
		self.DIALOGUE = None
		self.dialogue = 0

		"""
			information sur l'ennemi (vaisseau)
		"""

		self.ennemi = None

	def inventaire_aliens(self,couleur):
		self.NOM = texteCentre(self.bordure[0]//2,self.bordure[2]+50,self.personnage,couleur)
		self.OBJET = Alien(self.bordure[0]//2,self.bordure[3]-50,0,0,70,couleur).dessiner()

	def mise_a_jour_inventaire(self,couleur="green"):
		if self.personnage == "Aliens":
			efface(self.VIE)
			self.VIE = texteCentre(self.bordure[0]//2,self.bordure[3]+50,"Aliens: {}".format(len(self.aliens)),couleur)
		elif self.personnage == "Boss":
			efface(self.JAUGE)
			self.JAUGE = rectanglePlein(50,400,1+self.points_vie,450,"#c61aff")

	def initialisation(self):
		for ordonnee in range(self.bordure[2],self.bordure[3],self.bordure[3]//self.ligne):
			for abscisse in range(self.bordure[0],self.bordure[1],self.bordure[1]//self.colonne):
				self.aliens.append(Alien(abscisse,ordonnee,self.pas[randint(0,10)],self.pas[randint(0,10)]))
				self.aliens[len(self.aliens)-1].dessiner()

		self.personnage = "Aliens"
		self.inventaire_aliens("green")
		self.mise_a_jour_inventaire()

	def collision_ennemi(self,alien):
		if sqrt(pow(alien.abs-self.ennemi.abs,2)+pow(alien.ord-self.ennemi.ord,2))<=(self.ennemi.taille*2)+alien.taille:
			self.ennemi.blesser()

	def deplacer_alien(self,alien):
		if self.animation == 1:
			if alien.ord < 100:
				alien.pas_x = 0
				alien.pas_y = 5
			else:
				alien.pas_y = 0
				if self.dialogue > 0:
					if self.DIALOGUE == None:
						self.DIALOGUE = texteCentre(137,500,"Prépare toi\nà Mourir!!!","black")
				else:
					efface(self.DIALOGUE)
					self.animation = 0

		else:
			if alien.abs + alien.pas_x <= self.bordure[0] :
				if self.personnage == "Aliens":
					alien.pas_x = self.pas[randint(6,10)]
			if alien.abs + alien.pas_x >= self.bordure[1] :
				if self.personnage == "Aliens":
					alien.pas_x = self.pas[randint(0,4)]

			if alien.ord + alien.pas_y <= self.bordure[2] :
				if self.personnage == "Aliens":
					alien.pas_y = self.pas[randint(6,10)]
				elif self.personnage == "Boss":
					alien.pas_y = 1

			if alien.ord + alien.pas_y >= self.bordure[3] :
				if self.personnage == "Aliens":
					alien.pas_y = self.pas[randint(0,4)]
				elif self.personnage == "Boss":
					alien.pas_y = -1		
		
		self.collision_ennemi(alien)

		alien.eliminer()
		alien.abs += int(alien.pas_x)
		alien.ord += int(alien.pas_y)
		alien.mise_a_jour_position()
		return alien

	def en_mouvement(self):
		self.aliens = list(map(self.deplacer_alien,self.aliens))
		for alien in self.aliens:
			alien.dessiner()	
			if self.personnage=="Aliens" and randint(0,100) == 5:
				self.tirs.append(alien.attaquer())
				self.tirs[len(self.tirs)-1].tirer()
			if self.personnage =="Boss" and randint(0,200)%10 == 0 and self.animation == 0:
				self.tirs.append(alien.attaquer("precision",self.ennemi.abs,self.ennemi.ord))
				self.tirs[len(self.tirs)-1].tirer()
	
	def position_ennemi(self,ennemi):
		self.ennemi = ennemi

	# Si un des tirs des aliens a atteint le vaisseau
	def cible_atteinte(self,tir):
		if sqrt(pow(tir.abs-self.ennemi.abs,2)+pow(tir.ord-self.ennemi.ord,2))<=(self.ennemi.taille*2 + tir.taille):
			return True
		return False

	def deplacer_tir(self,tir):
		if tir != None:
			#On verifie première si le tir a touché sa cible
			if self.cible_atteinte(tir) == True:
				self.ennemi.blesser()
				tir.effacer()
			else:
				if self.personnage =="Aliens":
					if tir.ord < self.bordure[3]*2:
						tir.ord +=10
						tir.effacer()
						return tir
					else:
						tir.effacer()
				elif self.personnage == "Boss":
					if tir.coef_dir == "abscisse":
						if tir.x > 550:
							if tir.abs < 825 :
								tir.abs +=1
								tir.effacer()
								return tir
							else:
								tir.effacer()
						if tir.x < 550:
							if tir.abs > 275:
								tir.abs -=1
								tir.effacer()
								return tir
							else:
								tir.effacer()
						else:
							tir.effacer()
					elif tir.coef_dir == "ordonnee":
						if tir.y > 300:
							if  tir.ord < 600:
								tir.ord +=1
								tir.effacer()
								return tir
							else:
								tir.effacer()
						if tir.y < 300:
							if tir.ord > 0:
								tir.ord -=1
								tir.effacer()
								return tir
							else:
								tir.effacer()
						else:
							tir.effacer()
						self.ennemi.blesser()
					elif tir.coef_dir == "origine":
						tir.effacer()
					else:
						if tir.x > 550:
							if tir.abs < 825:
								if tir.y > 300:
									if tir.ord < 600:
										tir.abs += 1
										tir.ord = tir.coef_dir*tir.abs + tir.origine
										tir.effacer()
										return tir
									else:
										tir.effacer()
								if tir.y < 300 :
									if tir.ord > 0:
										tir.abs +=1
										tir.ord = tir.coef_dir*tir.abs + tir.origine
										tir.effacer()
										return tir
									else:
										tir.effacer()
							else:
								tir.effacer()
						if tir.x < 550:
							if tir.abs > 275:
								if tir.y > 300 :
									if tir.ord < 600:
										tir.abs -= 1
										tir.ord = tir.coef_dir*tir.abs + tir.origine
										tir.effacer()
										return tir
									else:
										tir.effacer()
								if tir.y < 300 :
									if tir.ord > 0:
										tir.abs -=1
										tir.ord = tir.coef_dir*tir.abs + tir.origine
										tir.effacer()
										return tir
									else:
										tir.effacer()
							else:
								tir.effacer()							

	def aliens_attaquent(self):
		self.tirs = list(map(self.deplacer_tir,self.tirs))
		for tir in self.tirs:
			if tir == None:
				self.tirs.remove(tir)
			else:
				tir.tirer()

	def le_boss(self):
		efface(self.OBJET)
		efface(self.NOM)
		efface(self.VIE)

		self.animation = 1
		self.dialogue = 100
		self.personnage = "Boss"
		self.inventaire_aliens("#c61aff")
		self.VIE = texteCentre(self.bordure[0]//2,self.bordure[3]+50,"Vie:","#c61aff")
		self.bordure = [375,725,100,200] 
		self.JAUGE = rectanglePlein(50,400,1+self.points_vie,450,"#c61aff")
		