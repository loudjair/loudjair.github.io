#coding:utf-8
from iutk import *
from plateau import *
from time import sleep
from figures import *

class Jeu:
	def __init__(self,largeur,hauteur,titre):
		#Dimensions de la fenetre 
		self.Fenetre_L = largeur
		self.Fenetre_H = hauteur
		self.titre = titre

		#Le plateau est représenter par une liste
		self.PLATEAU = Plateau(10,10)

		"""
			1er dico : 1er clic , 2eme dico : 2eme clic
			On stocke les cases qui présentent des occurences
			Deux types d'occurences: couleurs et formes
			Des occurences présentent dans plusieurs directions du plateau:
			0 : Ouest , 1 : Est , 2: Nord et 3: Sud
		"""
		self.COMBO_F = [{0:[],1:[],2:[],3:[]},{0:[],1:[],2:[],3:[]}]
		self.COMBO_C = [{0:[],1:[],2:[],3:[]},{0:[],1:[],2:[],3:[]}]

		self.case_eliminer_combo0 = 0
		self.case_eliminer_combo1 = 0
		self.case0_dedans = 0
		self.case1_dedans = 0

		#Les couleurs et les formes possibles
		self.COULEURS = ["navy","red3","sea green","gold"]
		self.FORMES = ["CERCLE","RECTANGLE","LOSANGE","TRIANGLE"]
		
		self.TEXTE = None

		# Les cases sélectionnées 
		self.case0 = None
		self.case1 = None

		#Le score
		self.points = 0
		self.SCORE = None


	def ouvrirFenetre(self):
		creeFenetre(self.Fenetre_L,self.Fenetre_H,self.titre)

	"""
		Les fonctions éliminations sont charées de vider
		les cases du plateau , où il y a des occurences.
	"""

	# Elimination des cases horizontaux qui ont des occurences de figures géometriques
	def elimination_figure_horizontaux(self,ordre):
		# Des occurences sont présentent dans la même rangée dans les deux sens.
		# 0 : ouest et 1 : est
		if len(self.COMBO_F[ordre][0]) > 0 and len(self.COMBO_F[ordre][1]) > 0:
			for i in range(2):
				for case in self.COMBO_F[ordre][i]:
					if self.PLATEAU.plateau[case]["forme"] != None:
						if ordre == 0:
							if case != self.case1:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case1_dedans += 1
							self.case_eliminer_combo0 += 1

						elif ordre == 1:
							if case != self.case0:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case0_dedans += 1
		
							self.case_eliminer_combo1 += 1

		# Des occurences sont présentent dans la rangée mais dans un seul sens.					
		else:
			#variable pour représente 0 (ouest) et 1 (est)
			sens = -1
			#ouest
			if len(self.COMBO_F[ordre][0]) > 1 :
				sens = 0
				self.COMBO_F[ordre][1]=[]
			#est
			elif len(self.COMBO_F[ordre][1]) > 1 :
				sens = 1
				self.COMBO_F[ordre][0]=[]
			if sens != -1 :
				for case in self.COMBO_F[ordre][sens]:
					if self.PLATEAU.plateau[case]["forme"] != None:
						if ordre == 0:
							if case != self.case1:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case1_dedans += 1
							self.case_eliminer_combo0 += 1

						elif ordre == 1:
							if case != self.case0:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case0_dedans += 1
							self.case_eliminer_combo1 += 1

	def elimination_figure_verticaux(self,ordre):
		if len(self.COMBO_F[ordre][2]) > 0 and len(self.COMBO_F[ordre][3]) > 0:
			for i in range(2,4):
				for case in self.COMBO_F[ordre][i]:
					if self.PLATEAU.plateau[case]["forme"] != None:
						if ordre == 0:
							if case != self.case1:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case1_dedans += 1
							self.case_eliminer_combo0 += 1

						elif ordre == 1:
							if case != self.case0:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case0_dedans += 1
							self.case_eliminer_combo1 += 1	
		else:
			sens = -1
			#nord
			if len(self.COMBO_F[ordre][2]) > 1 :
				sens = 2
				self.COMBO_F[ordre][3]=[]
			#sud
			elif len(self.COMBO_F[ordre][3]) > 1 :
				sens = 3
				self.COMBO_F[ordre][2]=[]
			if sens != -1:
				for case in self.COMBO_F[ordre][sens]:
					if self.PLATEAU.plateau[case]["forme"] != None:
						if ordre == 0:
							if case != self.case1:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case1_dedans += 1
							self.case_eliminer_combo0 += 1

						elif ordre == 1:
							if case != self.case0:
								efface(self.PLATEAU.plateau[case]["forme"].dessin)
								self.PLATEAU.plateau[case]["forme"] = None
							else:
								self.case0_dedans += 1
							self.case_eliminer_combo1 += 1	

	def elimination_combo_figure(self,ordre):	
		self.elimination_figure_horizontaux(ordre)
		self.elimination_figure_verticaux(ordre)
		# Elimination des cases verticaux

	def elimination_couleur_horizontaux(self,ordre):
		if len(self.COMBO_C[ordre][0]) > 0 and len(self.COMBO_C[ordre][1]) > 0:
			for i in range(2):
				for case in self.COMBO_C[ordre][i]:
					if ordre == 0:
						if case != self.case1:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case1_dedans += 1
						self.case_eliminer_combo0 += 1

					elif ordre == 1:
						if case != self.case0:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case0_dedans += 1
						self.case_eliminer_combo1 += 1
		else:
			#variable pour représente 0 (ouest) et 1 (est)
			sens = -1
			#ouest
			if len(self.COMBO_C[ordre][0]) > 1 :
				sens = 0
				self.COMBO_C[ordre][1] = []
			#est
			elif len(self.COMBO_C[ordre][1]) > 1 :
				sens = 1
				self.COMBO_C[ordre][0] = []
			if sens != -1 :
				for case in self.COMBO_C[ordre][sens]:
					if ordre == 0:
						if case != self.case1:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case1_dedans += 1
						self.case_eliminer_combo0 += 1

					elif ordre == 1:
						if case != self.case0:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case0_dedans += 1
						self.case_eliminer_combo1 += 1

	def elimination_couleur_verticaux(self,ordre):
		if len(self.COMBO_C[ordre][2]) > 0 and len(self.COMBO_C[ordre][3]) > 0:
			for i in range(2,4):
				for case in self.COMBO_C[ordre][i]:
					if ordre == 0:
						if case != self.case1:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case1_dedans += 1
						self.case_eliminer_combo0 += 1

					elif ordre == 1:
						if case != self.case0:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case0_dedans += 1
						self.case_eliminer_combo1 += 1

		else:
			sens = -1
			#nord
			if len(self.COMBO_C[ordre][2]) > 1 :
				sens = 2
				self.COMBO_C[ordre][3]=[]
			#sud
			elif len(self.COMBO_C[ordre][3]) > 1 :
				sens = 3
				self.COMBO_C[ordre][2]=[]
			if sens != -1:
				for case in self.COMBO_C[ordre][sens]:
					if ordre == 0:
						if case != self.case1:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case1_dedans += 1
						self.case_eliminer_combo0 += 1

					elif ordre == 1:
						if case != self.case0:
							efface(self.PLATEAU.plateau[case]["forme"].dessin)
							self.PLATEAU.plateau[case]["forme"] = None
						else:
							self.case0_dedans += 1
						self.case_eliminer_combo1 += 1

	def elimination_combo_couleur(self,ordre):
		self.elimination_couleur_horizontaux(ordre)
		self.elimination_couleur_verticaux(ordre)
		# Elimination des cases verticaux

	def combo_ouest(self,case,ordre):
		indice = case
		ajout = 0
		while case%10 != 0 and (indice)%10 != 0:
			if self.PLATEAU.plateau[indice-1]["forme"]!= None:
				if self.PLATEAU.plateau[case]["forme"].forme==self.PLATEAU.plateau[indice]["forme"].forme==self.PLATEAU.plateau[indice-1]["forme"].forme:
					self.COMBO_F[ordre][0].append(indice-1)
					ajout += 1
				if self.PLATEAU.plateau[case]["forme"].couleur ==self.PLATEAU.plateau[indice]["forme"].couleur == self.PLATEAU.plateau[indice-1]["forme"].couleur:			
					self.COMBO_C[ordre][0].append(indice-1)
					ajout += 1
			if ajout < 1:
				break
			ajout = 0
			indice -= 1

	def combo_est(self,case,ordre):
		indice = case
		ajout = 0		
		while (case+1)%10 != 0 and (indice+1)%10 != 0:
			if self.PLATEAU.plateau[indice+1]["forme"]!= None:
				if self.PLATEAU.plateau[case]["forme"].forme == self.PLATEAU.plateau[indice]["forme"].forme == self.PLATEAU.plateau[indice+1]["forme"].forme:			
					self.COMBO_F[ordre][1].append(indice+1)
					ajout += 1
				if self.PLATEAU.plateau[case]["forme"].couleur ==self.PLATEAU.plateau[indice]["forme"].couleur == self.PLATEAU.plateau[indice+1]["forme"].couleur:			
					self.COMBO_C[ordre][1].append(indice+1)
					ajout += 1
			if ajout < 1:
				break
			indice += 1
			ajout = 0

	def combo_nord(self,case,ordre):
		indice = case
		ajout = 0
		while (case-10) >-1 and (indice-10)>-1:
			if self.PLATEAU.plateau[indice-10]["forme"]!= None:
				if self.PLATEAU.plateau[case]["forme"].forme == self.PLATEAU.plateau[indice]["forme"].forme == self.PLATEAU.plateau[indice-10]["forme"].forme:
					self.COMBO_F[ordre][2].append(indice-10)
					ajout += 1
				if self.PLATEAU.plateau[case]["forme"].couleur == self.PLATEAU.plateau[indice]["forme"].couleur == self.PLATEAU.plateau[indice-10]["forme"].couleur:
					self.COMBO_C[ordre][2].append(indice-10)
					ajout += 1	
			if ajout < 1:
				break
			indice -=10
			ajout = 0

	def combo_sud(self,case,ordre):
		indice = case
		ajout = 0		
		while (case+10) < 100 and (indice+10) < 100:
			if self.PLATEAU.plateau[indice+10]["forme"]!= None:
				if self.PLATEAU.plateau[case]["forme"].forme ==self.PLATEAU.plateau[indice]["forme"].forme == self.PLATEAU.plateau[indice+10]["forme"].forme:
					self.COMBO_F[ordre][3].append(indice+10)
					ajout += 1
				if self.PLATEAU.plateau[case]["forme"].couleur == self.PLATEAU.plateau[indice]["forme"].couleur == self.PLATEAU.plateau[indice+10]["forme"].couleur:
					self.COMBO_C[ordre][3].append(indice+10)
					ajout += 1
			if ajout < 1:
				break
			indice +=10
			ajout = 0

	def combo(self,case,ordre):
		self.combo_ouest(case,ordre)
		self.combo_est(case,ordre)
		self.combo_nord(case,ordre)
		self.combo_sud(case,ordre)
	
		# Clignote les cases quand des combos se forment
		self.PLATEAU.cases_clignotent(self.COMBO_F[ordre],case)
		self.PLATEAU.cases_clignotent(self.COMBO_C[ordre],case)

		self.elimination_combo_couleur(ordre)
		self.elimination_combo_figure(ordre)

	def eliminer(self):
		type_elimination = 0
		if self.case_eliminer_combo0 > 0 and self.case_eliminer_combo1 > 0:
			type_elimination = 1
		elif self.case_eliminer_combo0 > 0:
			if self.case1_dedans > 0:
				type_elimination = 1
			else:
				efface(self.PLATEAU.plateau[self.case0]["forme"].dessin)
				self.PLATEAU.plateau[self.case0]["forme"] = None	
		elif self.case_eliminer_combo1 > 1:
			if self.case0_dedans > 0:
				type_elimination = 1
			else:
				efface(self.PLATEAU.plateau[self.case1]["forme"].dessin)
				self.PLATEAU.plateau[self.case1]["forme"] = None				
		if type_elimination == 1:
			for case in [self.case0,self.case1]:
				efface(self.PLATEAU.plateau[case]["forme"].dessin)
				self.PLATEAU.plateau[case]["forme"] = None
		
	def combler(self):
		cases_vides = []
		if self.case_eliminer_combo0 > 0:
			for tab in self.COMBO_C[0].values():
				cases_vides += tab
			for tab in self.COMBO_F[0].values():
				cases_vides += tab
			cases_vides += [self.case0]
			self.points += len(cases_vides)*2
		if self.case_eliminer_combo1 > 0:
			for tab in self.COMBO_C[1].values():
				cases_vides += tab
			for tab in self.COMBO_F[1].values():
				cases_vides += tab
			cases_vides += [self.case1]
			self.points += len(cases_vides)*2

		if self.case_eliminer_combo0 >0 or self.case_eliminer_combo1 > 0:
			self.PLATEAU.combler_cases_vides(cases_vides,self.FORMES,self.COULEURS)
			for i in [0,1]:
				self.COMBO_F[i] = {0:[],1:[],2:[],3:[]}
				self.COMBO_C[i] = {0:[],1:[],2:[],3:[]}
			self.case_eliminer_combo0 = 0
			self.case_eliminer_combo1 = 0

	def demarrage(self):
		self.PLATEAU.initialiser(self.FORMES,self.COULEURS)
		rectangleCouleur(550,50,650,100,"red")
		texte(550,60,"Quitter","red")
		miseAJour()

	def triple_occurence(self):
		self.PLATEAU.echanger(self.case0,self.case1)
		self.combo(self.case0,0)
		self.combo(self.case1,1)
		self.eliminer()
		miseAJour()
		self.combler()
		miseAJour()

	def quitter(self,posCurseur):
		if 550 <= posCurseur[0] <= 650 and 50 <= posCurseur[1] <= 100:
			return True

	def partie_en_cours(self):
		
		while True:
			#Affichage du score
			efface(self.SCORE)
			self.SCORE = texte(550,200,"Score: {}".format(self.points),"black")
			miseAJour()
			
			#Le premier clic
			premier_clic = attenteClic()
			
			# Le quitte la partie
			if self.quitter(premier_clic) ==True:
				break

			efface(self.TEXTE)

			#On vérifie si le joueur a cliqué sur le plateau
			if self.PLATEAU.sur_le_plateau(premier_clic):

				#La première case selectionnée
				self.case0 = self.PLATEAU.case_plateau(premier_clic)

				#Changement de la couleur de la case quand on lui clique dessus				
				self.PLATEAU.case_active(self.case0,"red")
				
				miseAJour()

				deuxieme_clic = attenteClic()

				if self.quitter(deuxieme_clic) == True:
					break

				while self.PLATEAU.sur_le_plateau(deuxieme_clic) == False:
					deuxieme_clic = attenteClic()
					if self.quitter(deuxieme_clic) == True:
						break					

				if self.quitter(deuxieme_clic) == True:
					break

				#La deuxieme case selectionnée
				self.case1 = self.PLATEAU.case_plateau(deuxieme_clic)

				#Changement de la couleur de la case quand on lui clique dessus
				self.PLATEAU.case_active(self.case1,"red")

				# On verifie si les cases sont voisines
				if self.PLATEAU.voisin(self.case0,self.case1):
					# On verifie si y a eu des triples occurences
					self.triple_occurence()
				
				#Sinon on affiche un message d'erreur
				else:
					self.TEXTE = texte(510,300,"Les cases doivent\nêtre voisines","red")

				# Désactivation des cases séléctionner avec un changement de couleur
				self.PLATEAU.case_active(self.case0,"black")
				self.PLATEAU.case_active(self.case1,"black")
				miseAJour()
			miseAJour()

	def menu(self):
		rectangleCouleur(350,100,450,140,"blue")
		texteCentre(400,120,"Jouer","blue")
		rectangleCouleur(350,150,450,190,"red")
		texteCentre(400,170,"Quitter","red")

		texte = "Le but du jeu :\n"
		texte += "Former au moins trois figures\n"
		texte += "qui sont soient de la même couleur\n"
		texte += "ou de la même forme\n ou les deux"

		regle = texteCentre(400,300,texte,"black")

		while True:
			curseur = attenteClic()
			if 350 <= curseur[0] <= 450 and 100 <= curseur[1] <= 140:
				effaceTout()
				return 1
			elif  350 <= curseur[0] <= 450 and 150 <= curseur[1] <= 190:
				return 0