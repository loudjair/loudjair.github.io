#coding:utf-8

from jeu import *
from iutk import *

if __name__ == '__main__':

	three = Jeu(800,505,"Three to go")
	three.ouvrirFenetre()
	if three.menu() == 1:
		three.demarrage()
		three.partie_en_cours()
	fermeFenetre()