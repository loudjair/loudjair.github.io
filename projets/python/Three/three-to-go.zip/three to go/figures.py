#coding:utf-8

"""
	Classe permettant de représenter des coordonnées
"""
from iutk import *

class Coordonnee:
	def __init__(self,abscisse,ordonnee):
		self.abs = abscisse
		self.ord = ordonnee

"""
	Classe permettant de représenter les cases du plateau
"""

class Case(Coordonnee):
	def __init__(self,abscisse,ordonnee,taille,couleur="black",width=1):
		Coordonnee.__init__(self,abscisse,ordonnee)
		self.taille = taille
		self.couleur = couleur
		self.dessin = rectangleCouleur(self.abs,self.ord,self.abs+self.taille,self.ord+self.taille,self.couleur,width) 

"""
	Classe permettant de représenter les formes géometriques
"""

class Rectangle(Coordonnee):
	def __init__(self,abscisse,ordonnee,taille,couleur):
		Coordonnee.__init__(self,abscisse,ordonnee)
		self.couleur = couleur
		self.taille = taille
		self.forme = "RECTANGLE"
		self.dessin = rectanglePlein(self.abs,self.ord,self.abs+self.taille,self.ord+self.taille,self.couleur)

class Cercle(Coordonnee):
	def __init__(self,abscisse,ordonnee,rayon,couleur):
		Coordonnee.__init__(self,abscisse,ordonnee)
		self.rayon = rayon
		self.couleur = couleur
		self.forme = "CERCLE"
		self.dessin = cerclePlein(self.abs,self.ord,self.rayon,self.couleur)

"""
	Cette classe va permettre dessiner soit un triangle ou un losange
"""
class Polygone:
	def __init__(self,points,couleur,forme):
		self.points=points
		self.couleur = couleur
		self.forme = forme
		self.dessin = polygonePlein(self.points,self.couleur,"black")

def figure(x,y,taille,figure,couleur):
	if figure == "CERCLE":
		return Cercle(x+taille,y+taille,taille-5,couleur)
	elif figure == "RECTANGLE":
		return Rectangle(x+5,y+5,taille*2-10,couleur)
	elif figure == "LOSANGE":
		points = [[x+taille,y],[x,y+taille],[x+taille,y+taille*2],[x+taille*2,y+taille]]
		return Polygone(points,couleur,"LOSANGE")
	else:
		points = [[x+taille,y],[x,y+taille*2],[x+taille*2,y+taille*2]]
		return Polygone(points,couleur,"TRIANGLE")