#coding:utf-8
from figures import *
from random import randint
from math import fabs
from iutk import *
from time import sleep

class Plateau:

	def __init__(self,largeur,hauteur,pas=50):
		self.largeur = largeur
		self.hauteur = hauteur

		self.pas = pas
		self.plateau = dict()
		self.case = 0

		self.axe_grandeur = [(x,x+self.pas) for x in range(0,self.largeur*self.pas,self.pas)]

	def sens_ouest_couleur(self,couleurs):
		#ouest
		if (self.case-1) > -1 and (self.case%10) != 0 and (self.case-1) in self.plateau.keys():
			if (self.case-2) > -1 and (self.case-1)%10 != 0:
				if self.plateau[self.case-1]["forme"]!=None and self.plateau[self.case-2]["forme"]!=None:
					if self.plateau[self.case-1]["forme"].couleur == self.plateau[self.case-2]["forme"].couleur:
						if self.plateau[self.case-1]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-1]["forme"].couleur)
			#est
			if (self.case+1) < 100 and (self.case+1)%10 != 0 and (self.case+1) in self.plateau.keys():
				if self.plateau[self.case-1]["forme"]!=None and self.plateau[self.case+1]["forme"]!=None:
					if self.plateau[self.case-1]["forme"].couleur == self.plateau[self.case+1]["forme"].couleur:
						if self.plateau[self.case-1]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-1]["forme"].couleur)
		return couleurs
	
	def sens_est_couleur(self,couleurs):
		#est
		if (self.case+1) < 100 and (self.case+1)%10 != 0 and (self.case+1) in self.plateau.keys():
			if (self.case+2) < 100 and (self.case+2)%10 != 0:
				if self.plateau[self.case+1]["forme"]!= None and self.plateau[self.case+2]["forme"]!= None:
					if self.plateau[self.case+1]["forme"].couleur == self.plateau[self.case+2]["forme"].couleur:
						if self.plateau[self.case+1]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case+1]["forme"].couleur)
			#ouest
			if (self.case-1) > -1 and (self.case%10) != 0 and (self.case-1) in self.plateau.keys():
				if self.plateau[self.case-1]["forme"]!= None and self.plateau[self.case+1]["forme"]!= None:
					if self.plateau[self.case-1]["forme"].couleur == self.plateau[self.case+1]["forme"].couleur:
						if self.plateau[self.case-1]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-1]["forme"].couleur)
		return couleurs
	
	def sens_nord_couleur(self,couleurs):
		#nord
		if (self.case-10) > -1 and (self.case-10) in self.plateau.keys():
			if (self.case-20) > -1:
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case-20]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].couleur == self.plateau[self.case-20]["forme"].couleur:
						if self.plateau[self.case-10]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-10]["forme"].couleur)
			#sud
			if (self.case+10) < 100 and (self.case+10) in self.plateau.keys():
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case+10]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].couleur == self.plateau[self.case+10]["forme"].couleur:
						if self.plateau[self.case-10]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-10]["forme"].couleur)
		return couleurs
	
	def sens_sud_couleur(self,couleurs):
		#sud
		if (self.case+10) < 100 and (self.case+10) in self.plateau.keys():
			if (self.case+20) < 100:
				if self.plateau[self.case+10]["forme"]!= None and self.plateau[self.case+20]["forme"]!= None:
					if self.plateau[self.case+10]["forme"].couleur == self.plateau[self.case+20]["forme"].couleur:
						if self.plateau[self.case+10]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case+10]["forme"].couleur)
			#nord
			if (self.case-10) >-1 and (self.case-10) in self.plateau.keys():
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case+10]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].couleur == self.plateau[self.case+10]["forme"].couleur:
						if self.plateau[self.case-10]["forme"].couleur in couleurs:
							couleurs.remove(self.plateau[self.case-10]["forme"].couleur)
		return couleurs

	def sens_ouest_forme(self,formes):
		#ouest
		if (self.case-1) > -1 and (self.case%10) != 0 and (self.case-1) in self.plateau.keys():
			if (self.case-2) > -1 and (self.case-1)%10 != 0:
				if self.plateau[self.case-1]["forme"]!= None and self.plateau[self.case-2]["forme"]!= None:
					if self.plateau[self.case-1]["forme"].forme == self.plateau[self.case-2]["forme"].forme:
						if self.plateau[self.case-1]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-1]["forme"].forme)
			#est
			if (self.case+1) < 100 and (self.case+1)%10 != 0 and (self.case+1) in self.plateau.keys():
				if self.plateau[self.case-1]["forme"]!= None and self.plateau[self.case+1]["forme"]!= None:
					if self.plateau[self.case-1]["forme"].forme == self.plateau[self.case+1]["forme"].forme:
						if self.plateau[self.case-1]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-1]["forme"].forme)
		return formes
	
	def sens_est_forme(self,formes):
		#est
		if (self.case+1) < 100 and (self.case+1)%10 != 0 and (self.case+1) in self.plateau.keys():
			if (self.case+2) < 100 and (self.case+2)%10 != 0:
				if self.plateau[self.case+1]["forme"]!= None and self.plateau[self.case+2]["forme"]!= None:
					if self.plateau[self.case+1]["forme"].forme == self.plateau[self.case+2]["forme"].forme:
						if self.plateau[self.case+1]["forme"].forme in formes:
							formes.remove(self.plateau[self.case+1]["forme"].forme)
			#ouest
			if (self.case-1) > -1 and (self.case%10) != 0 and (self.case-1) in self.plateau.keys():
				if self.plateau[self.case-1]["forme"]!= None and self.plateau[self.case+1]["forme"]!= None:
					if self.plateau[self.case-1]["forme"].forme == self.plateau[self.case+1]["forme"].forme:
						if self.plateau[self.case-1]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-1]["forme"].forme)
		return formes
	
	def sens_nord_forme(self,formes):
		#nord
		if (self.case-10) > -1 and (self.case-10) in self.plateau.keys():
			if (self.case-20) > -1:
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case-20]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].forme == self.plateau[self.case-20]["forme"].forme:
						if self.plateau[self.case-10]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-10]["forme"].forme)
			#sud
			if (self.case+10) < 100 and (self.case+10) in self.plateau.keys():
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case+10]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].forme == self.plateau[self.case+10]["forme"].forme:
						if self.plateau[self.case-10]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-10]["forme"].forme)
		return formes
	
	def sens_sud_forme(self,formes):
		#sud
		if (self.case+10) < 100 and (self.case+10) in self.plateau.keys():
			if (self.case+20) < 100:
				if self.plateau[self.case+10]["forme"]!= None and self.plateau[self.case+20]["forme"]!= None:
					if self.plateau[self.case+10]["forme"].forme == self.plateau[self.case+20]["forme"].forme:
						if self.plateau[self.case+10]["forme"].forme in formes:
							formes.remove(self.plateau[self.case+10]["forme"].forme)
			#nord
			if (self.case-10) >-1 and (self.case-10) in self.plateau.keys():
				if self.plateau[self.case-10]["forme"]!= None and self.plateau[self.case+10]["forme"]!= None:
					if self.plateau[self.case-10]["forme"].forme == self.plateau[self.case+10]["forme"].forme:
						if self.plateau[self.case-10]["forme"].forme in formes:
							formes.remove(self.plateau[self.case-10]["forme"].forme)
		return formes

	def initialisation_couleur(self,couleurs):
		#Pour éviter à des triples occurences on procède à des verifications
		couleurs = self.sens_ouest_couleur(couleurs)
		couleurs = self.sens_est_couleur(couleurs)
		couleurs = self.sens_nord_couleur(couleurs)
		couleurs = self.sens_sud_couleur(couleurs)

		return couleurs[randint(0,len(couleurs)-1)]

	def initialisation_forme(self,formes):
		#Pour éviter à des triples occurences on procède à des verifications
		formes = self.sens_ouest_forme(formes)
		formes = self.sens_est_forme(formes)
		formes = self.sens_nord_forme(formes)
		formes = self.sens_sud_forme(formes)
		return formes[randint(0,len(formes)-1)]		

	# Initialisation du plateau
	def initialiser(self,formes,couleurs):

		for ordonnee in range(0, self.hauteur * self.pas, self.pas):
			for abscisse in range(0, self.largeur * self.pas, self.pas):
				self.plateau[self.case] = {
				"case":Case(abscisse,ordonnee,self.pas),
				"forme":None
				}
				forme = self.initialisation_forme(formes.copy())
				couleur = self.initialisation_couleur(couleurs.copy())
				self.plateau[self.case]["forme"] = figure(abscisse,ordonnee,self.pas//2,forme,couleur)
				self.case += 1


	def case_plateau(self,posCurseur):
		pos = Coordonnee(-1,-1)
		for x in self.axe_grandeur:
			# abscisse
			if x[0] <= posCurseur[0] <= x[1]:
				pos.abs = self.axe_grandeur.index(x)
			 # ordonnee
			if x[0] <= posCurseur[1] <= x[1]:
				pos.ord = self.axe_grandeur.index(x)
			if pos.abs != -1 and pos.ord != -1:
				break

		case = pos.abs
		for x in range(pos.ord):
			case +=self.hauteur
		return case

	def transition_verticale(self,pos0,pos1,figure0,figure1):
		# Variables qui vont recevoir temporairement les figures à afficer
		tmp0 = None
		tmp1 = None
		ord_f0 = pos0.ord
		ord_f1 = pos1.ord
		while True:
			if figure0 != None:
				tmp0 = figure(pos0.abs,ord_f0,(self.pas//2),figure0[0],figure0[1])
			tmp1 = figure(pos1.abs,ord_f1,(self.pas//2),figure1[0],figure1[1])
			miseAJour()
			if tmp0 != None: 
				efface(tmp0.dessin)
			efface(tmp1.dessin)
			sleep(0.01)
			if pos0.ord < pos1.ord:
				ord_f0 +=10
				ord_f1 -=10
			else:
				ord_f0 -=10
				ord_f1 +=10
			if ord_f0 == pos1.ord and ord_f1 == pos0.ord:
				break

	def transition_horizontale(self,pos0,pos1,figure0,figure1):
		# Variables qui vont recevoir temporairement les figures à afficer
		tmp0 = None
		tmp1 = None
		abs_f0 = pos0.abs
		abs_f1 = pos1.abs
		while True:
			tmp0 = figure(abs_f0,pos0.ord,(self.pas//2),figure0[0],figure0[1])
			tmp1 = figure(abs_f1,pos1.ord,(self.pas//2),figure1[0],figure1[1])
			miseAJour()
			efface(tmp0.dessin)
			efface(tmp1.dessin)
			sleep(0.01)
			if pos0.abs < pos1.abs:
				abs_f0 +=10
				abs_f1 -=10
			else:
				abs_f0 -=10
				abs_f1 +=10
			if abs_f0 == pos1.abs and abs_f1 == pos0.abs:
				break

	def echanger(self,case0,case1):
		pos = Coordonnee(self.axe_grandeur[case0%10][0],self.axe_grandeur[case0//10][0])
		pos1 = Coordonnee(self.axe_grandeur[case1%10][0],self.axe_grandeur[case1//10][0])

		if self.plateau[case0]["forme"] == None:
			if self.plateau[case1]["forme"] == None:
				return
			else:
				tmp = self.plateau[case1]["forme"].forme,self.plateau[case1]["forme"].couleur
				efface(self.plateau[case1]["forme"].dessin)
				self.transition_verticale(pos,pos1,None,tmp)
				self.plateau[case0]["forme"] = figure(pos.abs,pos.ord,(self.pas//2),tmp[0],tmp[1])
				self.plateau[case1]["forme"] = None
		else:
			tmp = self.plateau[case0]["forme"].forme,self.plateau[case0]["forme"].couleur
			tmp1 = self.plateau[case1]["forme"].forme,self.plateau[case1]["forme"].couleur
			# effacer
			efface(self.plateau[case0]["forme"].dessin)
			efface(self.plateau[case1]["forme"].dessin)
			
			#transition
			
			if pos.abs == pos1.abs :
				self.transition_verticale(pos,pos1,tmp,tmp1)
			elif pos.ord == pos1.ord :
				self.transition_horizontale(pos,pos1,tmp,tmp1)
			
			# echanger
			self.plateau[case0]["forme"] = figure(pos.abs,pos.ord,(self.pas//2),tmp1[0],tmp1[1])
			self.plateau[case1]["forme"] = figure(pos1.abs,pos1.ord,(self.pas//2),tmp[0],tmp[1])

	def sur_le_plateau(self,posCurseur):
		if posCurseur == None:
			return False
		else:
			if 0 <= posCurseur[0] <= self.largeur * self.pas:
				if 0<= posCurseur[1] <= self.hauteur * self.pas:
					return True
			return False

	def voisin(self,case0,case1):
		if int(fabs(case0-case1)) != 1 and int(fabs(case0-case1)) != 10:
			return False
		return True

	def case_active(self,case,couleur,width=1):
		abscisse = self.axe_grandeur[case%10][0]
		ordonnee = self.axe_grandeur[case//10][0]
		
		efface(self.plateau[case]["case"].dessin)
		self.plateau[case]["case"] = Case(abscisse,ordonnee,self.pas,couleur,width)

	def combler_cases_vides(self,cases_vides,formes,couleurs):
		#on trie la liste des cases en ordre décroissant
		#Pour pouvoir traiter les cases les plus bas du plateau 
		
		cases_vides.sort(reverse=True) #!!!!!!Important!!!!!!!
		
		for case in cases_vides:
			if self.plateau[case]["forme"] == None:
				#on verifie si la case appartient à la rangée du haut du plateau
				if (case//10) == 0:
					self.case = case
					forme = self.initialisation_forme(formes.copy())
					couleur = self.initialisation_couleur(couleurs.copy())
					pos = Coordonnee(self.axe_grandeur[case%10][0],0)
					self.plateau[case]["forme"] = figure(pos.abs,pos.ord,self.pas//2,forme,couleur)
				else:
					#distance qui sépare une case vide à une case pleine
					distance = 0
					i = case
					while i//10 != 0 and self.plateau[i]["forme"]==None:
						i -= 10
						distance += 10
					if i//10 == 0:
						while distance > -1:
							if self.plateau[i]["forme"]==None:
								 #!! pour initialiser forme et couleur!!
								self.case = distance + i
								forme = self.initialisation_forme(formes.copy())
								couleur = self.initialisation_couleur(couleurs.copy())
								pos = Coordonnee(self.axe_grandeur[i][0],0)
								self.plateau[i]["forme"] = figure(pos.abs,0,self.pas//2,forme,couleur)
							if distance != 0:
								self.echanger(i+distance,i)
							distance -=10				
					else:
						i = case
						while (i//10)>-1:
							if distance < 20:
								if (i//10) == 0 :
									self.case = i
									forme = self.initialisation_forme(formes.copy())
									couleur = self.initialisation_couleur(couleurs.copy())
									pos = Coordonnee(self.axe_grandeur[i%10][0],0)
									self.plateau[i]["forme"] = figure(pos.abs,pos.ord,self.pas//2,forme,couleur)
									break
								else:
									self.echanger(i,i-distance)
							else:
								if i >((distance-10)+(i%10)):
									self.echanger(i,i-distance)
								else:
									self.case = i
									forme = self.initialisation_forme(formes.copy())
									couleur = self.initialisation_couleur(couleurs.copy())
									pos = Coordonnee(self.axe_grandeur[i%10][0],0)
									self.plateau[i%10]["forme"] = figure(pos.abs,pos.ord,self.pas//2,forme,couleur)
									if (i//10) != 0:
										self.echanger(i,i%10)
							i -=10
	def cases_clignotent(self,combos,case_courant):
		for direction in [(0,1),(2,3)]:
			if len(combos[direction[0]]) > 0 and len(combos[direction[1]]) > 0:
				#clignotement 3 fois
				for i in range(3):
					#activation des cases en rouge 
					for case in combos[direction[0]]:
						self.case_active(case,"red",3)
					for case in combos[direction[1]]:
						self.case_active(case,"red",3)
					self.case_active(case_courant,"red",3)
					miseAJour()
					sleep(0.1)
					#désactivation des cases
					for case in combos[direction[0]]:
						self.case_active(case,"black")
					for case in combos[direction[1]]:
						self.case_active(case,"black")
					self.case_active(case,"black")
					miseAJour()
					sleep(0.1)
			else:
				#variable pour représente 0 (ouest) et 1 (est)
				sens = -1
				#ouest
				if len(combos[direction[0]]) > 1 :
					sens = direction[0]
				#est
				elif len(combos[direction[1]]) > 1 :
					sens = direction[1]
				if sens != -1 :
					#clignotement 3 fois
					for i in range(3):
						for case in combos[sens]:
							#activation des cases en rouge 
							self.case_active(case,"red",3)
						self.case_active(case_courant,"red",3)
						miseAJour()
						sleep(0.1)
						for case in combos[sens]:
							#désactivation des cases
							self.case_active(case,"black")
						self.case_active(case_courant,"black")
						miseAJour()
						sleep(0.1)		